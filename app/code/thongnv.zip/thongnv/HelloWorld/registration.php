<?php
/**
 * Module registration file
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'thongnv_HelloWorld',
    __DIR__
);