<?php
namespace  thongnv\HelloWorld\Controller\HomePage;

class Hello extends  \Magento\Framework\App\Action\Action{
    public function execute(){
         echo "Hello World Thong";
    }
}
?>